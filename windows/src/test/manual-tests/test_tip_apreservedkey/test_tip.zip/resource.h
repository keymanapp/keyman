//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SampleIME.rc
//
#define SUBLANG_ENGLISH_US              0x01
#define LANG_ENGLISH                    0x09
#define IDIS_SAMPLEIME                  12
#define IDS_DEFAULT_FONT                13
#define IDS_IME_MODE                    20
#define IDI_IME_MODE_ON                 21
#define IDI_IME_MODE_OFF                22
#define IDS_DOUBLE_SINGLE_BYTE          23
#define IDI_DOUBLE_SINGLE_BYTE_ON       24
#define IDI_DOUBLE_SINGLE_BYTE_OFF      25
#define IDS_PUNCTUATION                 26
#define IDI_PUNCTUATION_ON              27
#define IDI_PUNCTUATION_OFF             28
#define IDR_VERSION2                    107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
