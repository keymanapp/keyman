Put jeuclid.jar in this directory!
